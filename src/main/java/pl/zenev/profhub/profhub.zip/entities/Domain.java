package pl.zenev.profhub.entities;

public enum Domain {
    MATH,
    CHEMISTRY,
    PHYSICS
}
